/*global $*/
$(function () {
    
    "use strict";
    
    $("div.page-content > div").css({
        
        minHeight: $(window).height(),
        width: $(window).width() - $("ul.side-menu").width()
        
    });
    
    // Smooth Scroll
    
    $("ul.side-menu li").on("click", function () {
        
        $("html, body").animate({
            
            scrollTop: $('#' + $(this).data('value')).offset().top
            
        }, 2000);
        
    });
    
    // Fire Nice Scroll Plugin
    
    $("html").niceScroll({
        cursorcolor: "#2e343f",
        cursorborder: "none",
        cursorwidth: "6px",
        horizrailenabled: false,
        zindex: "5000"
    });
    
});